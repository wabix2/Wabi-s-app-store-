import { Category } from "@/types";

export const categories: Category[] = [
  {
    slug: "ai",
    label: "AI",
    description: "Apps powered by artificial intelligence and machine learning.",
    icon: "Brain",
    color: "#7c5cfc",
  },
  {
    slug: "education",
    label: "Education",
    description: "Learn faster, retain more, grow every day.",
    icon: "GraduationCap",
    color: "#10b981",
  },
  {
    slug: "research",
    label: "Research",
    description: "Tools for academics, students, and curious minds.",
    icon: "FlaskConical",
    color: "#f59e0b",
  },
  {
    slug: "tools",
    label: "Tools",
    description: "Productivity utilities and everyday essentials.",
    icon: "Wrench",
    color: "#00d4ff",
  },
];
