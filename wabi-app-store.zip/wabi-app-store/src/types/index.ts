export type AppCategory = "AI" | "Education" | "Research" | "Tools";

export interface AppVersion {
  version: string;
  date: string;
  notes: string;
  apk?: string;
}

export interface AppScreenshot {
  src: string;
  alt: string;
}

export interface App {
  id: string;
  name: string;
  tagline: string;
  description: string;
  longDescription: string;
  version: string;
  category: AppCategory;
  icon: string;
  color: string; // accent color for card
  apk: string;
  github: string;
  screenshots: AppScreenshot[];
  features: string[];
  techStack: string[];
  downloads: number;
  featured: boolean;
  releaseDate: string;
  versionHistory: AppVersion[];
  tags: string[];
}

export interface Category {
  slug: string;
  label: AppCategory;
  description: string;
  icon: string;
  color: string;
}
