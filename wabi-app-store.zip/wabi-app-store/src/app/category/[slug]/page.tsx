import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getAppsByCategory } from "@/lib/apps";
import { categories } from "@/data/categories";
import { AppCard } from "@/components/AppCard";
import { Brain, GraduationCap, FlaskConical, Wrench } from "lucide-react";
import { AppCategory } from "@/types";

interface Props {
  params: { slug: string };
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Brain, GraduationCap, FlaskConical, Wrench,
};

export async function generateStaticParams() {
  return categories.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const cat = categories.find((c) => c.slug === params.slug);
  if (!cat) return { title: "Not Found" };
  return {
    title: `${cat.label} Apps`,
    description: cat.description,
  };
}

export default function CategoryPage({ params }: Props) {
  const cat = categories.find((c) => c.slug === params.slug);
  if (!cat) notFound();

  const apps = getAppsByCategory(cat.label as AppCategory);
  const Icon = iconMap[cat.icon] ?? Brain;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-8">
      {/* Header */}
      <div className="flex items-center gap-5">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0"
          style={{ background: `${cat.color}20`, color: cat.color }}
        >
          <Icon className="w-7 h-7" />
        </div>
        <div>
          <p className="section-label">{cat.label}</p>
          <h1 className="font-display font-bold text-3xl text-text-primary mt-0.5">
            {cat.label} Apps
          </h1>
          <p className="text-text-secondary text-sm mt-1">{cat.description}</p>
        </div>
      </div>

      {/* Apps */}
      {apps.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {apps.map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 space-y-3">
          <Icon className="w-12 h-12 mx-auto text-text-muted" />
          <p className="text-text-secondary">No apps in this category yet.</p>
          <p className="text-sm text-text-muted">Check back soon!</p>
        </div>
      )}
    </div>
  );
}
