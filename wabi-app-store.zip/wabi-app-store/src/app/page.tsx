import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Package } from "lucide-react";
import { getFeaturedApp, getLatestApps, getAllApps } from "@/lib/apps";
import { FeaturedAppHero } from "@/components/FeaturedAppHero";
import { AppCard } from "@/components/AppCard";
import { CategoryGrid } from "@/components/CategoryGrid";
import { SearchBar } from "@/components/SearchBar";

export const metadata: Metadata = {
  title: "Wabi App Store — Personal Software Distribution",
  description: "Download open-source Android apps built with passion. AI tools, education apps, research utilities, and more.",
};

export default function HomePage() {
  const featured = getFeaturedApp();
  const latest = getLatestApps(4);
  const total = getAllApps().length;

  return (
    <div className="relative">
      {/* Hero background */}
      <div className="absolute inset-0 h-[600px] bg-hero-gradient pointer-events-none" />
      <div className="absolute inset-0 h-[600px] bg-grid pointer-events-none opacity-60" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-24 space-y-20">

        {/* Hero Section */}
        <section className="text-center space-y-6 animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-accent/10 border border-accent/25 rounded-full text-accent text-sm font-medium">
            <Package className="w-3.5 h-3.5" />
            {total} apps published
          </div>

          <h1 className="font-display font-bold text-4xl sm:text-5xl md:text-6xl text-text-primary tracking-tight max-w-2xl mx-auto leading-[1.1]">
            Apps built to{" "}
            <span className="gradient-text">make you better</span>
          </h1>

          <p className="text-text-secondary text-lg max-w-xl mx-auto leading-relaxed">
            A personal distribution platform for open-source Android apps. Free, transparent, no Play Store required.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <SearchBar className="w-full sm:w-72" />
            <Link href="/apps" className="btn-ghost w-full sm:w-auto justify-center">
              Browse All Apps
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </section>

        {/* Featured App */}
        {featured && (
          <section className="space-y-4 animate-fade-up stagger-1">
            <div className="flex items-center justify-between">
              <p className="section-label">Featured</p>
            </div>
            <FeaturedAppHero app={featured} />
          </section>
        )}

        {/* Categories */}
        <section className="space-y-4 animate-fade-up stagger-2">
          <div className="flex items-center justify-between">
            <p className="section-label">Categories</p>
          </div>
          <CategoryGrid />
        </section>

        {/* Latest Apps */}
        <section className="space-y-4 animate-fade-up stagger-3">
          <div className="flex items-center justify-between">
            <p className="section-label">Latest Apps</p>
            <Link href="/apps" className="text-sm text-text-secondary hover:text-accent transition-colors flex items-center gap-1">
              View all <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {latest.map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="relative overflow-hidden rounded-2xl border border-accent/20 bg-elevated text-center p-12 space-y-5">
          <div className="absolute inset-0 bg-grid opacity-30 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-br from-accent/5 to-transparent pointer-events-none" />
          <div className="relative z-10 space-y-4">
            <h2 className="font-display font-bold text-2xl md:text-3xl text-text-primary">
              All apps are free & open-source
            </h2>
            <p className="text-text-secondary max-w-md mx-auto">
              Every app here ships with a public GitHub repo. Audit the code, fork it, improve it.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Link href="/apps" className="btn-primary">
                <Package className="w-4 h-4" />
                Explore Apps
              </Link>
              <a
                href="https://github.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost"
              >
                View on GitHub
              </a>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
