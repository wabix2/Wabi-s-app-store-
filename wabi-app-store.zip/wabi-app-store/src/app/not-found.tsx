import Link from "next/link";

export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4 space-y-6">
      <div className="font-mono text-8xl font-bold text-accent/20">404</div>
      <h1 className="font-display font-bold text-2xl text-text-primary">Page not found</h1>
      <p className="text-text-secondary max-w-sm">
        This page doesn't exist, or the app you're looking for hasn't been published yet.
      </p>
      <div className="flex gap-3">
        <Link href="/" className="btn-primary">Go home</Link>
        <Link href="/apps" className="btn-ghost">Browse apps</Link>
      </div>
    </div>
  );
}
