import type { Metadata } from "next";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  title: {
    default: "Wabi App Store — Personal Software Distribution",
    template: "%s | Wabi App Store",
  },
  description:
    "A personal software distribution platform. Download APKs, explore open-source apps, and follow development updates.",
  keywords: ["android apps", "apk download", "open source", "indie apps"],
  openGraph: {
    type: "website",
    siteName: "Wabi App Store",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-void text-text-primary antialiased min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
