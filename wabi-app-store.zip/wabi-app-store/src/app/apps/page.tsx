import type { Metadata } from "next";
import { getAllApps, searchApps, getAppsByCategory } from "@/lib/apps";
import { AppCard } from "@/components/AppCard";
import { SearchBar } from "@/components/SearchBar";
import { CategoryBadge } from "@/components/CategoryBadge";
import Link from "next/link";
import { Package } from "lucide-react";
import { AppCategory } from "@/types";

export const metadata: Metadata = {
  title: "All Apps",
  description: "Browse all published apps — AI tools, education, research utilities, and more.",
};

const CATEGORIES: AppCategory[] = ["AI", "Education", "Research", "Tools"];

interface AppsPageProps {
  searchParams: { q?: string; category?: string };
}

export default function AppsPage({ searchParams }: AppsPageProps) {
  const { q, category } = searchParams;

  let apps = getAllApps();

  if (q) {
    apps = searchApps(q);
  } else if (category) {
    const cat = CATEGORIES.find((c) => c.toLowerCase() === category.toLowerCase());
    if (cat) apps = getAppsByCategory(cat);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-8">
      {/* Header */}
      <div className="space-y-4">
        <p className="section-label">Apps</p>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-display font-bold text-3xl text-text-primary">
              {q ? `Results for "${q}"` : category ? `${category} Apps` : "All Apps"}
            </h1>
            <p className="text-text-secondary mt-1 text-sm">
              {apps.length} app{apps.length !== 1 ? "s" : ""} found
            </p>
          </div>
          <SearchBar className="w-full sm:w-72" />
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap gap-2">
          <Link
            href="/apps"
            className={`tag text-xs transition-all ${
              !q && !category
                ? "bg-accent/20 border-accent/40 text-accent"
                : "border-border text-text-secondary hover:border-accent/30 hover:text-text-primary"
            }`}
          >
            All
          </Link>
          {CATEGORIES.map((cat) => (
            <Link
              key={cat}
              href={`/apps?category=${cat.toLowerCase()}`}
              className={`tag text-xs transition-all ${
                category?.toLowerCase() === cat.toLowerCase()
                  ? "bg-accent/20 border-accent/40 text-accent"
                  : "border-border text-text-secondary hover:border-accent/30 hover:text-text-primary"
              }`}
            >
              {cat}
            </Link>
          ))}
        </div>
      </div>

      {/* Apps Grid */}
      {apps.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {apps.map((app) => (
            <AppCard key={app.id} app={app} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20 space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-elevated border border-border flex items-center justify-center mx-auto">
            <Package className="w-8 h-8 text-text-muted" />
          </div>
          <h3 className="font-semibold text-text-primary">No apps found</h3>
          <p className="text-text-secondary text-sm">
            Try a different search or{" "}
            <Link href="/apps" className="text-accent hover:underline">
              browse all apps
            </Link>
          </p>
        </div>
      )}
    </div>
  );
}
