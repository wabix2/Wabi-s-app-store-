import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Github, ArrowLeft, Calendar, Tag, Code2, History, CheckCircle2, Package } from "lucide-react";
import { getAppById, getAllApps, formatDownloads } from "@/lib/apps";
import { AppIcon } from "@/components/AppIcon";
import { CategoryBadge } from "@/components/CategoryBadge";
import { DownloadButton } from "@/components/DownloadButton";

interface Props {
  params: { id: string };
}

export async function generateStaticParams() {
  return getAllApps().map((app) => ({ id: app.id }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const app = getAppById(params.id);
  if (!app) return { title: "App Not Found" };
  return {
    title: `${app.name} — ${app.tagline}`,
    description: app.description,
  };
}

export default function AppDetailPage({ params }: Props) {
  const app = getAppById(params.id);
  if (!app) notFound();

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Back */}
      <Link
        href="/apps"
        className="inline-flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Apps
      </Link>

      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-border bg-elevated p-8 md:p-10">
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            background: `radial-gradient(ellipse 60% 60% at 80% 50%, ${app.color} 0%, transparent 70%)`,
          }}
        />
        <div className="relative z-10 flex flex-col md:flex-row items-start gap-7">
          <AppIcon name={app.name} color={app.color} size="xl" />

          <div className="flex-1 space-y-4">
            <div className="flex flex-wrap items-start gap-3">
              <CategoryBadge category={app.category} />
              <span className="tag text-xs border-border text-text-muted">
                v{app.version}
              </span>
              {app.featured && (
                <span className="tag text-xs" style={{ color: app.color, borderColor: `${app.color}40`, background: `${app.color}15` }}>
                  Featured
                </span>
              )}
            </div>

            <h1 className="font-display font-bold text-3xl md:text-4xl text-text-primary tracking-tight">
              {app.name}
            </h1>
            <p className="text-text-secondary text-lg leading-relaxed">{app.tagline}</p>

            <div className="flex flex-wrap gap-5 text-sm text-text-muted pt-1">
              <span className="flex items-center gap-1.5">
                <Package className="w-4 h-4" />
                {formatDownloads(app.downloads)} downloads
              </span>
              <span className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4" />
                Released {new Date(app.releaseDate).toLocaleDateString("en-US", { year: "numeric", month: "short" })}
              </span>
            </div>

            <div className="flex flex-wrap gap-3 pt-2">
              <DownloadButton apkUrl={app.apk} appId={app.id} version={app.version} size="lg" />
              <a
                href={app.github}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost"
              >
                <Github className="w-4 h-4" />
                View Source
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Screenshots placeholder */}
      {app.screenshots.length > 0 ? (
        <section className="space-y-4">
          <h2 className="font-display font-semibold text-lg text-text-primary">Screenshots</h2>
          <div className="flex gap-4 overflow-x-auto pb-2">
            {app.screenshots.map((s, i) => (
              <div key={i} className="shrink-0 w-48 h-96 rounded-xl bg-elevated border border-border overflow-hidden">
                <img src={s.src} alt={s.alt} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </section>
      ) : (
        <section className="space-y-4">
          <h2 className="font-display font-semibold text-lg text-text-primary">Screenshots</h2>
          <div className="flex gap-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="shrink-0 w-44 h-80 rounded-xl bg-elevated border border-border flex items-center justify-center"
              >
                <p className="text-xs text-text-muted text-center px-4">
                  Screenshot {i}<br />coming soon
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Two column layout */}
      <div className="grid md:grid-cols-3 gap-8">
        {/* Main content */}
        <div className="md:col-span-2 space-y-10">
          {/* Description */}
          <section className="space-y-3">
            <h2 className="font-display font-semibold text-lg text-text-primary flex items-center gap-2">
              About {app.name}
            </h2>
            <p className="text-text-secondary leading-relaxed">{app.longDescription}</p>
          </section>

          {/* Features */}
          <section className="space-y-4">
            <h2 className="font-display font-semibold text-lg text-text-primary flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-accent" />
              Features
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {app.features.map((feature) => (
                <div
                  key={feature}
                  className="flex items-start gap-2.5 p-3 rounded-lg bg-elevated border border-border"
                >
                  <div className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{ background: app.color }} />
                  <span className="text-sm text-text-secondary">{feature}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Version History */}
          <section className="space-y-4">
            <h2 className="font-display font-semibold text-lg text-text-primary flex items-center gap-2">
              <History className="w-5 h-5 text-accent" />
              Version History
            </h2>
            <div className="space-y-3">
              {app.versionHistory.map((v, i) => (
                <div
                  key={v.version}
                  className="p-4 rounded-xl bg-elevated border border-border space-y-2"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <span
                        className="font-mono font-semibold text-sm"
                        style={{ color: i === 0 ? app.color : undefined }}
                      >
                        v{v.version}
                      </span>
                      {i === 0 && (
                        <span
                          className="text-xs px-2 py-0.5 rounded-full"
                          style={{ background: `${app.color}20`, color: app.color }}
                        >
                          Latest
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-text-muted">
                      {new Date(v.date).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}
                    </span>
                  </div>
                  <p className="text-sm text-text-secondary">{v.notes}</p>
                  {v.apk && (
                    <a
                      href={v.apk}
                      download
                      className="inline-flex items-center gap-1.5 text-xs text-text-muted hover:text-accent transition-colors"
                    >
                      Download this version →
                    </a>
                  )}
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Tech Stack */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-sm text-text-primary flex items-center gap-2">
              <Code2 className="w-4 h-4 text-accent" />
              Tech Stack
            </h3>
            <div className="flex flex-wrap gap-2">
              {app.techStack.map((tech) => (
                <span
                  key={tech}
                  className="text-xs px-2.5 py-1 rounded-full bg-void border border-border text-text-secondary font-mono"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-sm text-text-primary flex items-center gap-2">
              <Tag className="w-4 h-4 text-accent" />
              Tags
            </h3>
            <div className="flex flex-wrap gap-2">
              {app.tags.map((tag) => (
                <Link
                  key={tag}
                  href={`/apps?q=${tag}`}
                  className="text-xs px-2.5 py-1 rounded-full bg-void border border-border text-text-muted hover:border-accent/40 hover:text-accent transition-all"
                >
                  #{tag}
                </Link>
              ))}
            </div>
          </div>

          {/* Links */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-sm text-text-primary">Links</h3>
            <div className="space-y-2">
              <a
                href={app.github}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2.5 text-sm text-text-secondary hover:text-text-primary transition-colors"
              >
                <Github className="w-4 h-4" />
                GitHub Repository
              </a>
            </div>
          </div>

          {/* Download CTA */}
          <div
            className="rounded-xl p-5 space-y-3 border"
            style={{ background: `${app.color}10`, borderColor: `${app.color}30` }}
          >
            <p className="text-sm font-semibold text-text-primary">Ready to install?</p>
            <p className="text-xs text-text-muted">
              Direct APK download. No Play Store, no tracking.
            </p>
            <DownloadButton apkUrl={app.apk} appId={app.id} version={app.version} className="w-full justify-center" />
          </div>
        </div>
      </div>
    </div>
  );
}
