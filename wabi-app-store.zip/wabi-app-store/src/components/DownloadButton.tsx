"use client";

import { useState, useEffect } from "react";
import { Download, Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface DownloadButtonProps {
  apkUrl: string;
  appId: string;
  version: string;
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function DownloadButton({
  apkUrl,
  appId,
  version,
  className,
  size = "md",
}: DownloadButtonProps) {
  const [downloaded, setDownloaded] = useState(false);
  const [count, setCount] = useState(0);

  useEffect(() => {
    const stored = localStorage.getItem(`downloads_${appId}`);
    if (stored) setCount(parseInt(stored, 10));
  }, [appId]);

  const handleDownload = () => {
    const newCount = count + 1;
    setCount(newCount);
    localStorage.setItem(`downloads_${appId}`, newCount.toString());
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  };

  const sizeClasses = {
    sm: "text-xs px-3 py-1.5",
    md: "text-sm px-5 py-2.5",
    lg: "text-base px-6 py-3",
  };

  return (
    <a
      href={apkUrl}
      download
      onClick={handleDownload}
      className={cn(
        "inline-flex items-center gap-2 font-medium rounded-lg transition-all duration-200 active:scale-[0.98]",
        downloaded
          ? "bg-green-500/20 border border-green-500/30 text-green-400"
          : "bg-accent hover:bg-accent-soft text-white shadow-accent-sm hover:shadow-accent-md",
        sizeClasses[size],
        className
      )}
    >
      {downloaded ? (
        <>
          <Check className="w-4 h-4" />
          Downloading…
        </>
      ) : (
        <>
          <Download className="w-4 h-4" />
          Download APK v{version}
        </>
      )}
    </a>
  );
}
