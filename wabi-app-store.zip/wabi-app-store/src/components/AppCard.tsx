import Link from "next/link";
import { Download, ArrowRight, Github } from "lucide-react";
import { App } from "@/types";
import { AppIcon } from "./AppIcon";
import { CategoryBadge } from "./CategoryBadge";
import { formatDownloads } from "@/lib/apps";

interface AppCardProps {
  app: App;
}

export function AppCard({ app }: AppCardProps) {
  return (
    <div className="card card-hover group flex flex-col p-5 gap-4">
      {/* Header */}
      <div className="flex items-start gap-4">
        <AppIcon name={app.name} color={app.color} size="md" />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display font-semibold text-text-primary text-base leading-tight truncate">
              {app.name}
            </h3>
            <CategoryBadge category={app.category} />
          </div>
          <p className="text-xs text-text-muted mt-0.5">v{app.version}</p>
        </div>
      </div>

      {/* Description */}
      <p className="text-sm text-text-secondary leading-relaxed line-clamp-2 flex-1">
        {app.tagline}
      </p>

      {/* Meta */}
      <div className="flex items-center gap-3 text-xs text-text-muted">
        <span className="flex items-center gap-1">
          <Download className="w-3 h-3" />
          {formatDownloads(app.downloads)}
        </span>
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500/80" />
          Active
        </span>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 pt-1 border-t border-border">
        <a
          href={app.apk}
          download
          className="btn-primary text-xs px-3 py-1.5 flex-1 justify-center"
          onClick={(e) => e.stopPropagation()}
        >
          <Download className="w-3 h-3" />
          Download APK
        </a>
        <Link
          href={`/apps/${app.id}`}
          className="btn-ghost text-xs px-3 py-1.5"
        >
          <ArrowRight className="w-3 h-3" />
          Details
        </Link>
        <a
          href={app.github}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-ghost text-xs px-2.5 py-1.5"
          aria-label="GitHub"
          onClick={(e) => e.stopPropagation()}
        >
          <Github className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
}
