import Link from "next/link";
import { Download, Github, Star, ArrowRight } from "lucide-react";
import { App } from "@/types";
import { AppIcon } from "./AppIcon";
import { CategoryBadge } from "./CategoryBadge";
import { formatDownloads } from "@/lib/apps";

interface FeaturedAppHeroProps {
  app: App;
}

export function FeaturedAppHero({ app }: FeaturedAppHeroProps) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-elevated">
      {/* Background glow */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          background: `radial-gradient(ellipse 70% 60% at 70% 50%, ${app.color} 0%, transparent 70%)`,
        }}
      />
      {/* Grid */}
      <div className="absolute inset-0 bg-grid opacity-50" />

      <div className="relative z-10 p-8 md:p-12 flex flex-col md:flex-row items-start md:items-center gap-8">
        {/* Left: Info */}
        <div className="flex-1 space-y-5">
          <div className="flex items-center gap-3">
            <span className="tag text-xs" style={{ color: app.color, borderColor: `${app.color}40`, background: `${app.color}15` }}>
              <Star className="w-3 h-3 mr-1" fill="currentColor" />
              Featured App
            </span>
            <CategoryBadge category={app.category} />
          </div>

          <div className="flex items-center gap-4">
            <AppIcon name={app.name} color={app.color} size="lg" />
            <div>
              <h2 className="font-display font-bold text-3xl md:text-4xl text-text-primary tracking-tight">
                {app.name}
              </h2>
              <p className="text-text-secondary mt-1">{app.tagline}</p>
            </div>
          </div>

          <p className="text-text-secondary text-sm leading-relaxed max-w-lg">
            {app.description}
          </p>

          <div className="flex flex-wrap gap-2">
            {app.features.slice(0, 3).map((f) => (
              <span key={f} className="text-xs px-2.5 py-1 bg-void/50 border border-border rounded-full text-text-muted">
                {f}
              </span>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a href={app.apk} download className="btn-primary">
              <Download className="w-4 h-4" />
              Download v{app.version}
            </a>
            <Link href={`/apps/${app.id}`} className="btn-ghost">
              View Details
              <ArrowRight className="w-4 h-4" />
            </Link>
            <a
              href={app.github}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost"
            >
              <Github className="w-4 h-4" />
              Source
            </a>
          </div>
        </div>

        {/* Right: Stats */}
        <div className="flex md:flex-col gap-4 md:gap-6 shrink-0">
          {[
            { label: "Downloads", value: formatDownloads(app.downloads) },
            { label: "Version", value: `v${app.version}` },
            { label: "Category", value: app.category },
          ].map(({ label, value }) => (
            <div key={label} className="text-center min-w-[80px]">
              <p
                className="font-display font-bold text-2xl"
                style={{ color: app.color }}
              >
                {value}
              </p>
              <p className="text-xs text-text-muted mt-0.5">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
