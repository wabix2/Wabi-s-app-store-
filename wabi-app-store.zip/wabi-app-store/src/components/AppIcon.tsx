import { cn } from "@/lib/utils";

interface AppIconProps {
  name: string;
  color: string;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}

const sizeMap = {
  sm: "w-10 h-10 text-base",
  md: "w-14 h-14 text-xl",
  lg: "w-18 h-18 text-2xl",
  xl: "w-24 h-24 text-3xl",
};

export function AppIcon({ name, color, size = "md", className }: AppIconProps) {
  const initials = name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <div
      className={cn(
        "rounded-2xl flex items-center justify-center font-display font-bold text-white shadow-lg shrink-0",
        sizeMap[size],
        className
      )}
      style={{
        background: `linear-gradient(135deg, ${color}dd 0%, ${color}88 100%)`,
        boxShadow: `0 4px 20px ${color}40`,
      }}
    >
      {initials}
    </div>
  );
}
