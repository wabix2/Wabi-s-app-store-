import Link from "next/link";
import { Brain, GraduationCap, FlaskConical, Wrench, ArrowRight } from "lucide-react";
import { categories } from "@/data/categories";
import { getAllApps } from "@/lib/apps";
import { AppCategory } from "@/types";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Brain,
  GraduationCap,
  FlaskConical,
  Wrench,
};

export function CategoryGrid() {
  const apps = getAllApps();

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {categories.map((cat) => {
        const Icon = iconMap[cat.icon] ?? Brain;
        const count = apps.filter((a) => a.category === (cat.label as AppCategory)).length;

        return (
          <Link
            key={cat.slug}
            href={`/category/${cat.slug}`}
            className="card card-hover group p-5 flex flex-col gap-3"
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: `${cat.color}20`, color: cat.color }}
            >
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold text-text-primary text-sm group-hover:text-accent transition-colors">
                {cat.label}
              </h3>
              <p className="text-xs text-text-muted mt-0.5">{count} app{count !== 1 ? "s" : ""}</p>
            </div>
            <p className="text-xs text-text-muted leading-relaxed flex-1">{cat.description}</p>
            <div className="flex items-center gap-1 text-xs" style={{ color: cat.color }}>
              <span>Browse</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </Link>
        );
      })}
    </div>
  );
}
