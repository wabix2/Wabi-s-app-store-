import Link from "next/link";
import { Zap, Github, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center">
                <Zap className="w-3.5 h-3.5 text-white" fill="white" />
              </div>
              <span className="font-display font-semibold text-text-primary">
                Wabi <span className="text-accent">Store</span>
              </span>
            </Link>
            <p className="text-sm text-text-muted leading-relaxed">
              A personal software distribution platform. Open-source, transparent, indie.
            </p>
            <div className="flex gap-3">
              <a
                href="https://github.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-elevated border border-border text-text-secondary hover:text-text-primary hover:border-accent/40 transition-all"
                aria-label="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href="https://twitter.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-elevated border border-border text-text-secondary hover:text-text-primary hover:border-accent/40 transition-all"
                aria-label="Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Apps */}
          <div>
            <h3 className="text-sm font-semibold text-text-primary mb-4">Apps</h3>
            <ul className="space-y-2.5">
              {[
                { href: "/apps", label: "All Apps" },
                { href: "/category/ai", label: "AI Apps" },
                { href: "/category/education", label: "Education" },
                { href: "/category/research", label: "Research" },
                { href: "/category/tools", label: "Tools" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-text-secondary hover:text-text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Featured */}
          <div>
            <h3 className="text-sm font-semibold text-text-primary mb-4">Featured</h3>
            <ul className="space-y-2.5">
              {[
                { href: "/apps/lumiq", label: "Lumiq" },
                { href: "/apps/wabi-notes", label: "Wabi Notes" },
                { href: "/apps/researchiq", label: "ResearchIQ" },
                { href: "/apps/vocabuilder", label: "VocaBuilder" },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-text-secondary hover:text-text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-text-muted">
            © {new Date().getFullYear()} Wabi App Store. Built with Next.js & love.
          </p>
          <p className="text-xs text-text-muted">
            All apps are open-source and free to use.
          </p>
        </div>
      </div>
    </footer>
  );
}
