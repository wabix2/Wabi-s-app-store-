import { AppCategory } from "@/types";
import { getCategoryColor } from "@/lib/apps";
import { cn } from "@/lib/utils";

interface CategoryBadgeProps {
  category: AppCategory;
  className?: string;
}

export function CategoryBadge({ category, className }: CategoryBadgeProps) {
  const color = getCategoryColor(category);
  return (
    <span
      className={cn("tag text-xs", className)}
      style={{
        color,
        borderColor: `${color}40`,
        backgroundColor: `${color}15`,
      }}
    >
      {category}
    </span>
  );
}
