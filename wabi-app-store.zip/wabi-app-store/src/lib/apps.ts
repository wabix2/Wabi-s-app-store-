import appsData from "@/data/apps.json";
import { App, AppCategory } from "@/types";

const apps = appsData as App[];

export function getAllApps(): App[] {
  return apps;
}

export function getFeaturedApp(): App | undefined {
  return apps.find((app) => app.featured);
}

export function getAppById(id: string): App | undefined {
  return apps.find((app) => app.id === id);
}

export function getAppsByCategory(category: AppCategory): App[] {
  return apps.filter((app) => app.category === category);
}

export function getLatestApps(count = 6): App[] {
  return [...apps]
    .sort(
      (a, b) =>
        new Date(b.releaseDate).getTime() - new Date(a.releaseDate).getTime()
    )
    .slice(0, count);
}

export function searchApps(query: string): App[] {
  const q = query.toLowerCase().trim();
  if (!q) return apps;
  return apps.filter(
    (app) =>
      app.name.toLowerCase().includes(q) ||
      app.description.toLowerCase().includes(q) ||
      app.tagline.toLowerCase().includes(q) ||
      app.tags.some((tag) => tag.includes(q)) ||
      app.category.toLowerCase().includes(q)
  );
}

export function formatDownloads(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return n.toString();
}

export function getCategoryColor(category: AppCategory): string {
  const map: Record<AppCategory, string> = {
    AI: "#7c5cfc",
    Education: "#10b981",
    Research: "#f59e0b",
    Tools: "#00d4ff",
  };
  return map[category] ?? "#7c5cfc";
}

export function getCategorySlug(category: AppCategory): string {
  return category.toLowerCase();
}
