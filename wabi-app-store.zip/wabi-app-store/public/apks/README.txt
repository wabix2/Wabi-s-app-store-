Place your APK files in this directory.

Naming convention:
  appname-v1.0.0.apk

Examples:
  lumiq-v1.0.0.apk
  lumiq-v1.1.0.apk
  wabi-notes-v0.9.1.apk

These are referenced in src/data/apps.json like:
  "apk": "/apks/lumiq-v1.2.0.apk"

For files over 100MB, host on GitHub Releases and use the external URL.
