import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
        display: ["var(--font-display)", "system-ui", "sans-serif"],
      },
      colors: {
        void: "#0a0a0f",
        surface: "#111118",
        elevated: "#1a1a24",
        border: "#2a2a3a",
        muted: "#3a3a50",
        accent: {
          DEFAULT: "#7c5cfc",
          soft: "#9d7ffe",
          dim: "#4a3599",
          glow: "rgba(124, 92, 252, 0.25)",
        },
        cyan: {
          glow: "#00d4ff",
          soft: "#7ee8ff",
        },
        text: {
          primary: "#f0eeff",
          secondary: "#a09abf",
          muted: "#60607a",
        },
      },
      backgroundImage: {
        "grid-pattern":
          "linear-gradient(rgba(124,92,252,0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(124,92,252,0.04) 1px, transparent 1px)",
        "hero-gradient":
          "radial-gradient(ellipse 80% 50% at 50% -20%, rgba(124,92,252,0.3) 0%, transparent 60%)",
        "card-gradient":
          "linear-gradient(135deg, rgba(26,26,36,0.9) 0%, rgba(17,17,24,0.95) 100%)",
      },
      backgroundSize: {
        grid: "40px 40px",
      },
      boxShadow: {
        "accent-sm": "0 0 20px rgba(124,92,252,0.15)",
        "accent-md": "0 0 40px rgba(124,92,252,0.2)",
        card: "0 1px 3px rgba(0,0,0,0.4), 0 8px 24px rgba(0,0,0,0.3)",
        "card-hover":
          "0 1px 3px rgba(0,0,0,0.5), 0 16px 48px rgba(0,0,0,0.4), 0 0 0 1px rgba(124,92,252,0.2)",
      },
      animation: {
        "fade-up": "fadeUp 0.5s ease forwards",
        "fade-in": "fadeIn 0.4s ease forwards",
        shimmer: "shimmer 2s linear infinite",
        float: "float 6s ease-in-out infinite",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-8px)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
