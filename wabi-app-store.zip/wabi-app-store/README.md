# Wabi App Store 🚀

A personal software distribution platform — your own mini Play Store for publishing Android APKs and open-source projects.

**Live demo**: [wabi-store.vercel.app](https://wabi-store.vercel.app) *(deploy to activate)*

---

## ✨ Features

- 🏪 **App Store UI** — Modern card-based listing inspired by Apple App Store + Stripe
- 📲 **Direct APK Downloads** — Host and distribute APK files straight from `/public/apks/`
- 🔍 **Search & Filter** — Search by name, tag, or category
- 📄 **App Detail Pages** — Screenshots, features, version history, tech stack, GitHub link
- 📦 **JSON-driven** — Add apps by editing a single JSON file
- 🌑 **Dark mode** — Default dark, beautiful
- 📱 **Fully responsive** — Mobile-first design
- 🔗 **GitHub integration** — Source code links on every app
- 📊 **Download counter** — Local tracking (API-ready)

---

## 🚀 Quick Start

```bash
git clone https://github.com/yourusername/wabi-app-store
cd wabi-app-store
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 📦 Adding a New App

**Step 1** — Open `src/data/apps.json` and add your app:

```json
{
  "id": "my-app",
  "name": "My App",
  "tagline": "Short one-liner description",
  "description": "Medium description for cards",
  "longDescription": "Full description for detail page",
  "version": "1.0.0",
  "category": "Tools",
  "icon": "/icons/my-app.svg",
  "color": "#ff6b35",
  "apk": "/apks/my-app-v1.0.0.apk",
  "github": "https://github.com/yourusername/my-app",
  "screenshots": [
    { "src": "/screenshots/my-app-1.png", "alt": "Home screen" }
  ],
  "features": [
    "Feature one",
    "Feature two"
  ],
  "techStack": ["Kotlin", "Jetpack Compose"],
  "downloads": 0,
  "featured": false,
  "releaseDate": "2025-06-25",
  "versionHistory": [
    {
      "version": "1.0.0",
      "date": "2025-06-25",
      "notes": "Initial release",
      "apk": "/apks/my-app-v1.0.0.apk"
    }
  ],
  "tags": ["utility", "android"]
}
```

**Step 2** — Add your APK:
```
public/apks/my-app-v1.0.0.apk
```

**Step 3** — Add screenshots (optional):
```
public/screenshots/my-app-1.png
```

That's it. The page auto-generates at `/apps/my-app`.

---

## 🗂️ Folder Structure

```
wabi-app-store/
├── src/
│   ├── app/                    # Next.js App Router pages
│   │   ├── page.tsx            # Home page
│   │   ├── apps/
│   │   │   ├── page.tsx        # All apps listing
│   │   │   └── [id]/
│   │   │       └── page.tsx    # App detail page
│   │   ├── category/
│   │   │   └── [slug]/
│   │   │       └── page.tsx    # Category pages
│   │   ├── layout.tsx          # Root layout
│   │   └── globals.css         # Global styles
│   ├── components/             # React components
│   │   ├── Navbar.tsx
│   │   ├── Footer.tsx
│   │   ├── AppCard.tsx
│   │   ├── AppIcon.tsx
│   │   ├── FeaturedAppHero.tsx
│   │   ├── CategoryGrid.tsx
│   │   ├── CategoryBadge.tsx
│   │   ├── SearchBar.tsx
│   │   └── DownloadButton.tsx
│   ├── data/
│   │   ├── apps.json           # ← ADD YOUR APPS HERE
│   │   └── categories.ts       # Category definitions
│   ├── lib/
│   │   ├── apps.ts             # App query utilities
│   │   └── utils.ts            # Helper functions
│   └── types/
│       └── index.ts            # TypeScript types
├── public/
│   ├── apks/                   # ← PUT YOUR APK FILES HERE
│   ├── icons/                  # App icons
│   └── screenshots/            # App screenshots
└── ...config files
```

---

## 🌐 Deployment

### Vercel (recommended)

```bash
npm install -g vercel
vercel --prod
```

Or: Connect your GitHub repo at [vercel.com/new](https://vercel.com/new) — zero config.

### Environment Variables

None required for base functionality. For analytics or a CMS API, add to `.env.local`:

```env
NEXT_PUBLIC_SITE_URL=https://your-domain.com
```

---

## 🔧 Customization

### Change the featured app
Set `"featured": true` on one app in `apps.json`. Only one app should be featured at a time.

### Add categories
Edit `src/data/categories.ts` to add new category types.

### Update branding
- Site name: `src/app/layout.tsx` → metadata
- Logo: `src/components/Navbar.tsx`
- Colors: `tailwind.config.ts`

---

## 📲 APK Hosting Tips

For large APKs (>100MB), consider:
- **GitHub Releases** — Free, version-tagged, CDN-served
- **Cloudflare R2** — Cheap object storage
- **Supabase Storage** — Free tier, easy API

Update the `apk` field in `apps.json` to point to the external URL.

---

## 🛣️ Roadmap

- [ ] RSS feed for app updates
- [ ] App ratings & comments (with GitHub Discussions)
- [ ] Admin panel (add/edit apps via UI)
- [ ] Server-side download counter (Supabase/PlanetScale)
- [ ] PWA support
- [ ] Email notifications for new app releases

---

## 📄 License

MIT — use it, fork it, build on it.
